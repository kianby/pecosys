#!/bin/sh
if [ $# = 1 ]; then 
    echo "graph_title Noise and Attenuation"
    echo "graph_category ADSL"
    echo "graph_vlabel dB"
    echo "upnoise.label Up noise"
    echo "downnoise.label Down noise"
    echo "upatt.label Up att"
    echo "downatt.label Down att"
else
    grep "bruit sens montant" adsl_stats.txt  | cut -s -d: -f2 | sed 's/\s*\([0-9]\+\)\(\.\?\)\([0-9]\?\).*/upnoise.value \1\2\3/'
    grep "bruit descendante" adsl_stats.txt  | cut -s -d: -f2 | sed 's/\s*\([0-9]\+\)\(\.\?\)\([0-9]\?\).*/downnoise.value \1\2\3/'
    grep "nuation montante" adsl_stats.txt  | cut -s -d: -f2 | sed 's/\s*\([0-9]\+\)\(\.\?\)\([0-9]\?\).*/upatt.value \1\2\3/'
    grep "nuation descendante" adsl_stats.txt  | cut -s -d: -f2 | sed 's/\s*\([0-9]\+\)\(\.\?\)\([0-9]\?\).*/downatt.value \1\2\3/'
fi
