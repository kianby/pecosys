#!/usr/bin/perl 
use warnings;
use strict;
=head1 livebox.pl

Control Livebox 2

=cut

use Getopt::Long;
use WWW::Mechanize::Sleepy "Sleepy";
use Pod::Usage;
use Digest::MD5 "md5";

my ( $user, $passwd ) = ( 'admin', 'admin' );
my $ip = '192.168.1.1';
my $page;
my ( $verbose, $progress ) = ( 0, 0 );

GetOptions(
    'user=s'   => \$user,
    'pass=s'   => \$passwd,
    'ip=s'     => \$ip,
    'page=s'   => \$page,
    'progress' => \$progress,
    'verbose'  => \$verbose,
    help       => sub { pod2usage( verbose => 2 ); },
) or pod2usage( verbose => 2 );

=head1 SYNOPSIS

livebox.pl [opt] [key=value,key=value, ...] [key=value,key=value, ...] 
 opt:
   --user=user            Set the username (defaults to admin)
   --pass=pass            Set the password (defaults to admin)
   --ip=ip                IP address of equipment (defaults to '192.168.1.1')
   --page=page            Which page(s) to GET after index
   --progress             Print Progress state
   --verbose              Print html traffic
   --help                 Show this message
=cut

my $mech = WWW::Mechanize::Sleepy->new( cookie_jar => undef, autocheck => 1, show_progress => $progress, timeout => 10, sleep => 1) or die("mech");

if ($verbose) {
    $|++;
    $mech->add_handler( "request_send", sub { print ">" x 80, "\n", shift->as_string; return } );
    $mech->add_handler( "response_done", sub { print "<" x 80, "\n", shift->as_string; return } );
}

warn "Trying to connect to $ip ...\n";

#LB2
#Record Session Id
$mech->get("http://$ip");
my $sessionid = $mech->value('sessionid');
#Hash password with authkey
my $authmd5passwd = unpack( 'H*', md5( unpack( 'H*', md5($passwd) ) . $mech->value('authkey') ) );
#Post Form to Authenticate
$mech->submit_form( with_fields => { authlogin => $user, authmd5passwd => $authmd5passwd } );

#Get the page if requested, otherwise exit
$page or exit;
$mech->get("http://$ip/index.cgi?page=$_&sessionid=$sessionid") for split m/,/, $page;

#Post Form as many times as requested
while ( my $values = shift ) {
    my %fields = map { m/^(.*?)=(.*)$/ } split m/,/, $values;
    $mech->submit_form( with_fields => \%fields );
}

=head1 EXAMPLES

=over 3

=item Display sys info

livebox.pl -page=infosys_main -v  | html2text

=item Display adsl info

livebox.pl -page=infosys_adsl -v  | html2text

=item Change wireless mode to 2 (b/g)

livebox.pl -page=wireless mode=2 

=item Reboot

livebox.pl -page=reboot action=submit action=reboot

=item Stop broadcasting SSID, set WPA2-PSK (AES) and activate MAC filtering

livebox.pl -page=wireless broadcast=0,securitymode=6,macfiltering=1

=item Change WPA Passphrase to 12345678

livebox.pl -page=wireless key=12345678

=back
=cut
