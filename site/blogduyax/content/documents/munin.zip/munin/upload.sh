#!/bin/sh
if [ $# = 1 ]; then 
    echo "graph_title Bandwidth - Upload"
    echo "graph_category ADSL"
    echo "graph_vlabel kb/s"
    echo "up.label upload"
else
    grep "bit montant maximum" adsl_stats.txt  | cut -s -d: -f2 | sed 's/\s*\([0-9]\+\).*/up.value \1/'
fi
