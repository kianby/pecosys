#!/bin/sh
#
# Gather livebox statistics and save into a text file
# added to crontab to collect data every 5 minutes
#
perl livebox.pl --user=admin --pass=admin -page=infosys_main -v 2>/dev/null | html2text >adsl_stats.txt
